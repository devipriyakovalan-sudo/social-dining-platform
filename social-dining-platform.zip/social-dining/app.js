// Filter cards by category
function filterCards(category, btn) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const cards = document.querySelectorAll('.card');
  let visible = 0;
  cards.forEach(card => {
    const match = category === 'all' || card.dataset.category === category;
    card.style.display = match ? 'block' : 'none';
    if (match) visible++;
  });
  document.getElementById('no-results').style.display = visible === 0 ? 'block' : 'none';
}

// Search cards by text
function searchCards() {
  const query = document.getElementById('search-input').value.toLowerCase();
  const cards = document.querySelectorAll('.card');
  let visible = 0;
  cards.forEach(card => {
    const text = card.innerText.toLowerCase();
    const match = text.includes(query);
    card.style.display = match ? 'block' : 'none';
    if (match) visible++;
  });
  document.getElementById('no-results').style.display = visible === 0 ? 'block' : 'none';
  // reset tab active state
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
}

// Toggle like button
function toggleLike(btn) {
  const liked = btn.classList.toggle('liked');
  const emoji = liked ? '❤️' : '🤍';
  const count = parseInt(btn.textContent.replace(/\D/g, ''));
  btn.textContent = `${emoji} ${liked ? count + 1 : count - 1}`;
}

// Add new dining card from modal
function addCard() {
  const name = document.getElementById('rest-name').value.trim();
  const location = document.getElementById('rest-location').value.trim();
  const category = document.getElementById('rest-category').value;
  const desc = document.getElementById('rest-desc').value.trim();

  if (!name || !location || !category || !desc) {
    alert('Please fill in all fields!');
    return;
  }

  const emojis = { 'south-indian': '🍱', 'north-indian': '🍛', 'chinese': '🍜', 'continental': '🥗' };
  const colors = { 'south-indian': '#f9a87520', 'north-indian': '#ef534020', 'chinese': '#42a5f520', 'continental': '#66bb6a20' };
  const labels = { 'south-indian': 'South Indian', 'north-indian': 'North Indian', 'chinese': 'Chinese', 'continental': 'Continental' };

  const card = document.createElement('div');
  card.className = 'card';
  card.dataset.category = category;
  card.innerHTML = `
    <div class="card-img" style="background:${colors[category]}">${emojis[category]}</div>
    <div class="card-body">
      <span class="badge ${category}">${labels[category]}</span>
      <h3>${name}</h3>
      <p>${desc}</p>
      <div class="card-footer">
        <span class="rating">⭐ New</span>
        <span class="location">📍 ${location}</span>
        <button class="btn-like" onclick="toggleLike(this)">🤍 0</button>
      </div>
    </div>`;

  document.getElementById('cards-grid').prepend(card);
  document.getElementById('share-modal').style.display = 'none';

  // reset form
  ['rest-name','rest-location','rest-category','rest-desc'].forEach(id => document.getElementById(id).value = '');
}

// Close modal on overlay click
document.getElementById('share-modal').addEventListener('click', function(e) {
  if (e.target === this) this.style.display = 'none';
});

// Live search on Enter key
document.getElementById('search-input').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') searchCards();
});
