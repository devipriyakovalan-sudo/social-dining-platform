# 🍽️ Social Dining Platform

A responsive web application for discovering and sharing dining experiences. Users can browse restaurant reviews by cuisine, search for specific experiences, like posts, and share their own dining stories.

## 🚀 Live Demo
> Open `index.html` in your browser — no server setup needed!

## 📸 Features

- **Browse & Filter** — Filter dining experiences by cuisine (South Indian, North Indian, Chinese, Continental)
- **Search** — Real-time search across all posts by keyword
- **Like System** — Like/unlike dining experiences
- **Share Experience** — Add your own restaurant review via a modal form
- **Responsive Design** — Works on mobile, tablet and desktop

## 🛠️ Tech Stack

| Technology | Usage |
|---|---|
| HTML5 | Page structure & semantic markup |
| CSS3 | Responsive layout, animations, card UI |
| JavaScript (Vanilla) | DOM manipulation, filtering, dynamic card creation |

## 📁 Project Structure

```
social-dining/
├── index.html     # Main HTML structure
├── style.css      # All styles and responsive design
├── app.js         # JavaScript logic (filter, search, like, add card)
└── README.md      # Project documentation
```

## 🏃 How to Run

1. Clone this repository:
   ```bash
   git clone https://github.com/devipriyakovalan/social-dining-platform.git
   ```
2. Open `index.html` in any web browser
3. No dependencies or installation required!

## 💡 Key Concepts Demonstrated

- Component-based UI using reusable card structures
- DOM manipulation and event handling in Vanilla JS
- CSS Grid and Flexbox for responsive layouts
- Modal implementation without any library
- Filter and search logic in JavaScript

## 👩‍💻 Author

**Devipriya Kovalan** — B.E. Computer Science, Thanthai Periyar Govt. Institute of Technology, Vellore  
📧 devipriyakovalan@gmail.com
